To install the module under Windows run

%PATH_TO_PYTHON%\python setup.py install